using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Event_registration
{
    #region My_event
    public class My_event
    {
        #region Member Variables
        protected int _id;
        protected string _title;
        protected string _description;
        protected unknown _event_date;
        protected unknown _event_time;
        protected string _location;
        protected string _promo_picture;
        protected unknown _create_date;
        protected unknown _deadline;
        protected string _organizer_id;
        #endregion
        #region Constructors
        public My_event() { }
        public My_event(string title, string description, unknown event_date, unknown event_time, string location, string promo_picture, unknown create_date, unknown deadline, string organizer_id)
        {
            this._title=title;
            this._description=description;
            this._event_date=event_date;
            this._event_time=event_time;
            this._location=location;
            this._promo_picture=promo_picture;
            this._create_date=create_date;
            this._deadline=deadline;
            this._organizer_id=organizer_id;
        }
        #endregion
        #region Public Properties
        public virtual int Id
        {
            get {return _id;}
            set {_id=value;}
        }
        public virtual string Title
        {
            get {return _title;}
            set {_title=value;}
        }
        public virtual string Description
        {
            get {return _description;}
            set {_description=value;}
        }
        public virtual unknown Event_date
        {
            get {return _event_date;}
            set {_event_date=value;}
        }
        public virtual unknown Event_time
        {
            get {return _event_time;}
            set {_event_time=value;}
        }
        public virtual string Location
        {
            get {return _location;}
            set {_location=value;}
        }
        public virtual string Promo_picture
        {
            get {return _promo_picture;}
            set {_promo_picture=value;}
        }
        public virtual unknown Create_date
        {
            get {return _create_date;}
            set {_create_date=value;}
        }
        public virtual unknown Deadline
        {
            get {return _deadline;}
            set {_deadline=value;}
        }
        public virtual string Organizer_id
        {
            get {return _organizer_id;}
            set {_organizer_id=value;}
        }
        #endregion
    }
    #endregion
}