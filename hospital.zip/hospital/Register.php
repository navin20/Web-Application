<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>My Title</title>


    <!-- Latest compiled and minified CSS --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" integrity="sha384-PmY9l28YgO4JwMKbTvgaS7XNZJ30MK9FAZjjzXtlqyZCqBY6X6bXIkM++IkyinN+" crossorigin="anonymous"> 
    <!-- Optional theme --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap-theme.min.css" integrity="sha384-jzngWsPS6op3fgRCDTESqrEJwRKck+CILhJVO5VvaAZCq8JYf8HsR/HPpBOOPZfR" crossorigin="anonymous"> 
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js" integrity="sha384-vhJnz1OVIdLktyixHY4Uk3OHEwdQqPppqYR8+5mjsauETgLOcEynD9oPHhhz18Nw" crossorigin="anonymous"></script>
    <link href = <link href=<link href="https://fonts.googleapis.com/css?family=Amaranth|Parisienne" rel="stylesheet">>


<style>
    body{
        background-color:white;
        background-image: url("ironman.jpg") 
        /* font-family: 'Parisienne', cursive */
    }

        </style>
    </head>
   
      
     
  <body>
  <div class="container text-center"  style = "margin-top:200px">
  <h1>
  <p class  = "text-danger">
  Register
  </p></h1>
  </div>
  <div class = "container text-center">
  <form class="form-horizontal" action="/action_page.php">
 
    <div class="form-group">
      <label class="control-label col-sm-5" for="email">
      <p class  = "text-warning"> Email Adress:</p> </label>
      <div class="col-sm-4">
        <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-5">
      <p class  = "text-warning"> First Name</p> </label>
      <div class="col-sm-4">
        <input type="email" class="form-control" id="first name" placeholder="Enter First Name" name="first name">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-5" >
      <p class  = "text-warning"> Last Name</p> </label>
      <div class="col-sm-4">
        <input type="email" class="form-control" id="last name" placeholder="Enter Last Name" name="last name">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-5" for="pwd"> <p class  = "text-warning">Password: </p></label>
      <div class="col-sm-4">          
        <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pwd">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-5" for="email">
      <p class  = "text-warning"> Phone Number</p> </label>
      <div class="col-sm-4">
        <input type="phone number" class="form-control" id="phone number" placeholder="Enter Phone Number" name="phone number">
      </div>
    </div>
    

    
    <div class="form-group">        
      <div class="col-sm-offset-6 col-sm-1">
        <button type="submit" class="btn btn-responsive">
        <a href = "signing.php">
        Organizer
        </a>
        </button>
      </div>
    </div>
    
    <div class="form-group">        
      <div class="col-sm-offset-6 col-sm-1">
        <button type="submit" class="btn btn-responsive">
        <a href = "participantlog.php">
        Participant
        </a>
        </button>
      </div>
    </div>
</div>
  </form>
</div>

   
    

<!-- <div class = "form-group">
  <label for "comment"><div class = "col-sm-4 bg-"> <h1> Personal Background </h1></label> </div>
  <textarea class="form-control" rows="5" id="comment"></textarea>
  
  
</div> -->

  </body>
</html>