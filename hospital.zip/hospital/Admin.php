<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>My Title</title>

    <!-- Latest compiled and minified CSS --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" integrity="sha384-PmY9l28YgO4JwMKbTvgaS7XNZJ30MK9FAZjjzXtlqyZCqBY6X6bXIkM++IkyinN+" crossorigin="anonymous"> 
    <!-- Optional theme --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap-theme.min.css" integrity="sha384-jzngWsPS6op3fgRCDTESqrEJwRKck+CILhJVO5VvaAZCq8JYf8HsR/HPpBOOPZfR" crossorigin="anonymous"> 
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js" integrity="sha384-vhJnz1OVIdLktyixHY4Uk3OHEwdQqPppqYR8+5mjsauETgLOcEynD9oPHhhz18Nw" crossorigin="anonymous"></script>
<head>
   <style>
   body{
    background-image:url("benz.jpg");
    font-size: 20px;
   }

   </style>
   </head>
   <body>
  

  
   <div class = "container-fluid text-center bg-primary" style = "margin-top:0px" >
      <h1>
        Total Sales for the day
  </h1>
  </div>
  <div class = "container-fluid text-center" style = "margin-top:100px">
  <table class = "table table-responsive">
    <tr>
    <td> <div  class = "bg-primary">receipt number</div> </td>
    <td> <p class = "bg-primary">Name</p> </td>
    <td> <p class = "bg-primary">illness</p> </td>
    <td> <p class = "bg-primary">cost</p> </td>
  </tr>
  <tr>
    <td> <p class = "bg-primary">1</p> </td>
    <td> <p class = "bg-primary">Namassakmask</p> </td>
    <td> <p class = "bg-primary">cold</p> </td>
    <td> <p class = "bg-primary"><?php $c =5000; echo 5000;?> baht</p> </td>
  </tr>
  <tr>
    <td> <p class = "bg-primary">2</p> </td>
    <td> <p class = "bg-primary">Nania</p> </td>
    <td> <p class = "bg-primary">illnesssmksnjsdah</p> </td>
    <td> <p class = "bg-primary"><?php $d =10000; echo 10000; ?> baht</p> </td>
  </tr>
  <tr>
    <td> <p class = "bg-primary">3</p> </td>
    <td> <p class = "bg-primary">IDK</p> </td>
    <td> <p class = "bg-primary">illnesssnjksands</p> </td>
    <td> <p class = "bg-primary"><?php $e =30000; echo 30000; ?> baht</p> </td>
  </tr>
  
  </table>
 
 
<table class = "table table-responsive">
  <tr>
    <td><font size = "20"><p class = "bg-primary"> Total</p></font></td>
    <td><font size = "20"><p class = "bg-primary"> <?php   echo ($c+$d+$e); ?></p> </font> <td>
      <?php
      ?>

  </tr>
  </table>
  
  
 



    


    
    
    





   </body>
   </html>