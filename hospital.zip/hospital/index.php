<!DOCTYPE html> 
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>My Title</title>

    <!-- Latest compiled and minified CSS --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" integrity="sha384-PmY9l28YgO4JwMKbTvgaS7XNZJ30MK9FAZjjzXtlqyZCqBY6X6bXIkM++IkyinN+" crossorigin="anonymous"> 
    <!-- Optional theme --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap-theme.min.css" integrity="sha384-jzngWsPS6op3fgRCDTESqrEJwRKck+CILhJVO5VvaAZCq8JYf8HsR/HPpBOOPZfR" crossorigin="anonymous"> 
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js" integrity="sha384-vhJnz1OVIdLktyixHY4Uk3OHEwdQqPppqYR8+5mjsauETgLOcEynD9oPHhhz18Nw" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css?family=Amaranth|Parisienne|Titan+One" rel="stylesheet">
    <link href="mystyle.css" rel="stylesheet">
   
   <style>
  
    body{
    background-image:url("ironman.jpg")
   }

	 </style>

  </head>
  <body>
  <div class="container-fluid  text-center " style = "margin-top:0px ; height:50px">
  

  <h1>
  <font size = "200">
  <?php

      // echo "ਸੋਨੀਆ ਮੇਰਾ ਬੌਸ ਹੈ<br>";
      // echo "\"Hello\"";
      $variable1 = 1;
      echo  "The result is:<br>";
      echo "This is a String";

?>
</font>
</h1>
  </div>
  <?php
  
  echo  $_REQUEST['email']
  ?>
  
 </body> 
    </html>
