<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>My Title</title>

    <!-- Latest compiled and minified CSS --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" integrity="sha384-PmY9l28YgO4JwMKbTvgaS7XNZJ30MK9FAZjjzXtlqyZCqBY6X6bXIkM++IkyinN+" crossorigin="anonymous"> 
    <!-- Optional theme --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap-theme.min.css" integrity="sha384-jzngWsPS6op3fgRCDTESqrEJwRKck+CILhJVO5VvaAZCq8JYf8HsR/HPpBOOPZfR" crossorigin="anonymous"> 
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js" integrity="sha384-vhJnz1OVIdLktyixHY4Uk3OHEwdQqPppqYR8+5mjsauETgLOcEynD9oPHhhz18Nw" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css?family=Amaranth|Parisienne|Titan+One" rel="stylesheet">
    
   
     

   



</head>
<body>
<nav class="navbar navbar-inverse"> <div class="container-fluid">
 <div class="navbar-header"> 
 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
  <span class="icon-bar">
  </span>
7
<span class="icon-bar">
</span> <span class="icon-bar"></span>
 </button> 
 <a class="navbar-brand" href="www.youtube.com">
 Eventing</a>
  </div> 
  <div class="collapse navbar-collapse" id="myNavbar">
   <ul class="nav navbar-nav"> 
   <li class="active">
   <a href="#">
   Home
   </a>
   </li>
   <li>
   <a href="#">
   Page 1
   </a>
   </li>
    <li>
    <a href="#">
    Page 2</a>
    </li> 
    <li>
    <a href="#">
    Page 3
    </a>
    </li>
     </ul>
      <ul class="nav navbar-nav navbar-right">
       <li>
       <a href="#">
       <span class="glyphicon glyphicon-user">
       </span>
        Sign Up
        </a>
        </li>
         <li>
         <a href="#">
         <span class="glyphicon glyphicon-log-in">
         </span>
          Login
          </a>


</li> 
<form class="navbar-form navbar-right" action="https://www.google.com/">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search" name="search">
     
        <div class="input-group-btn">
          <button class="btn btn-default" type="submit">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>

      
      <!-- <li class = "container-fluid"><a href="AdminConfirmation.php">
      <img src = "privateigno.png" style = "width:50px">  -->
       

</ul> </div> </div> </nav>



  
 
    
                 
               
        
               
               
                 <!-- </a> -->
                
  
  


    <!-- </form> -->
   
                <!-- </div>
                 </div> -->
                

