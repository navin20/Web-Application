<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>My Title</title>

    <!-- Latest compiled and minified CSS --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" integrity="sha384-PmY9l28YgO4JwMKbTvgaS7XNZJ30MK9FAZjjzXtlqyZCqBY6X6bXIkM++IkyinN+" crossorigin="anonymous"> 
    <!-- Optional theme --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap-theme.min.css" integrity="sha384-jzngWsPS6op3fgRCDTESqrEJwRKck+CILhJVO5VvaAZCq8JYf8HsR/HPpBOOPZfR" crossorigin="anonymous"> 
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js" integrity="sha384-vhJnz1OVIdLktyixHY4Uk3OHEwdQqPppqYR8+5mjsauETgLOcEynD9oPHhhz18Nw" crossorigin="anonymous"></script>

   
     

    <style>
      body{
        background-color:white;
        background-image: url("1.jpg")
       
      }
      * {
  box-sizing: border-box;
}

.column {
  float: left;
  
  
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
  width:30%
}
* {box-sizing: border-box}
.mySlides1, .mySlides2 {display: none}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

div.a{
  text-align:center
}
/* On hover, add a grey background color */
.prev:hover, .next:hover {
  background-color: yellow;
  color: black;
}
ul {

  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: red;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: blue;
}

.navbar {
  overflow: hidden;
  background-color: #333;
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 17px;    
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
  background-color: #ddd;
  color: black;
}

.dropdown:hover .dropdown-content {
  display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
}
}
}
        </style>
        </head>
        <body>
          
  <div class="container text-center"  style = "margin-top:200px">
  <h1>
  <p class  = "text-danger">
  Create Event
  </p></h1>
  </div>
  <div class = "container text-center">
  <form class="form-horizontal">
 
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">
      <p class  = "text-warning"> id</p> </label>
      <div class="col-sm-8">
        <input type="email" class="form-control" id="id" placeholder="Enter id" name="id">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">
      <p class  = "text-warning"> title</p> </label>
      <div class="col-sm-8">
        <input type="email" class="form-control" id="title" placeholder="Enter Title" name="title">
      </div>
    </div>
    <textarea rows="20" cols="50" name="description" form="usrform">
Enter Description here</textarea>

    
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">
      <p class  = "text-warning"> date</p> </label>
      <div class="col-sm-8">
        <input type="date" class="form-control" id="event_date" placeholder="Enter date of event" name="event_date">
      </div>
    </div>
      
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">
      <p class  = "text-warning"> time</p> </label>
      <div class="col-sm-8">
        <input type="time" class="form-control" id="event_time" placeholder="Enter time of the  event" name="event_time">
      </div>
    </div>
    
      
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">
      <p class  = "text-warning"> location</p> </label>
      <div class="col-sm-8">
        <input type = "location" class="form-control" id="location" placeholder="Enter location of the  event" name="location">
      </div>
    </div>
    
     
    <!-- <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-1">
        <button type="submit" class="btn btn-responsive">
        <a href = "pattaya.jpg">
        Promo Picture
        </a>
        </button>
      </div>
    </div> -->
    


    <div class="form-group">
      <label class="control-label col-sm-2" for="email">
      <p class  = "text-warning"> created date</p> </label>
      <div class="col-sm-8">
        <input type = "date" class="form-control" id="create_date" placeholder="Enter the creation date" name="create_date">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="email">
      <p class  = "text-warning"> deadline</p> </label>
      <div class="col-sm-8">
        <input type = "date" class="form-control" id="deadline" placeholder="Enter the deadline date" name="deadline">
      </div>
    </div>
    >

    <div class="form-group">
      <label class="control-label col-sm-2" for="email">
      <p class  = "text-warning"> organizer_id</p> </label>
      <div class="col-sm-5">
        <input type = "text" class="form-control" id="organizer_id" placeholder="Enter the organizer_id" name="organizer_id">
      </div>
    </div>
    


    




  



















    
    
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-1">
      <form>
        <button type="submit" class="btn btn-responsive"  value="Submit" onclick="msg()" >
        
  
</form>
        <a href = "newsign.php">
        Submit
        </a>
        </button>
      </div>
    </div>
</div>
  </form>
</div>


<script>
function msg() {
  alert("Bye!!");
}
</script>

        </body>
        </html>