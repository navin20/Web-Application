<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>My Title</title>

    <!-- Latest compiled and minified CSS --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" integrity="sha384-PmY9l28YgO4JwMKbTvgaS7XNZJ30MK9FAZjjzXtlqyZCqBY6X6bXIkM++IkyinN+" crossorigin="anonymous"> 
    <!-- Optional theme --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap-theme.min.css" integrity="sha384-jzngWsPS6op3fgRCDTESqrEJwRKck+CILhJVO5VvaAZCq8JYf8HsR/HPpBOOPZfR" crossorigin="anonymous"> 
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js" integrity="sha384-vhJnz1OVIdLktyixHY4Uk3OHEwdQqPppqYR8+5mjsauETgLOcEynD9oPHhhz18Nw" crossorigin="anonymous"></script>

   
     

    <style>
  
   body { 
  background: url("benz.jpg") no-repeat center fixed; 
  background-size: cover;
}


p.b { 
word-spacing: 30px;
margin-bottom:0px;


}

}
     

</style>

  </head>
  <body>

<!-- insert your codes here -->

<nav class="navbar navbar-inverse">
 <div class="container-fluid" style = "margin-bottom:0px">
  <div class="navbar-header">
   <button type="button" 
   class="navbar-toggle"
    data-toggle="collapse"
     data-target="#myNavbar">
      <span class="icon-bar">
      </span> <span class="icon-bar">
      </span> <span class="icon-bar">
      </span> </button>
       <a class="navbar-brand" 
       href="#">   นาวิน
   </a>
        </div>
         <div class="collapse navbar-collapse"
          id="myNavbar">
           <ul class="nav navbar-nav">
            <li class="active">
            <a href="#">
            <?php echo   
            "โฮมเพจ" ;?></a></li>
             <li><a href="Contact.php"
             >เกี่ยวกับเรา</a>
             </li>
              <li>
               
             
            
              
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"  class = "btn btn-red btn-lg">
             
         <span class = "glyphicon glyphicon-lock"> </span>
             
              ทางการแพทย์
             
     <span class="caret">
     </span>
     </a> 
     <ul class="dropdown-menu">
      <li><a href="#" class="btn btn-info btn-lg">
          <span class="glyphicon glyphicon-plus-sign"></span>  ภาพรวม
        </a>
     
      </a>
      </li>
        <li>
       <a href="emergency.php" class = "btn btn-danger btn-lg">
         <span class = "glyphicon glyphicon-plus-sign"> </span>
       กรณีฉุกเฉิน
       </a>
       </li>
       
      
        </ul> 
        <li>
        <a href="first.php" target = "blank">
          <span class="glyphicon glyphicon-refresh"></span> Refresh
        </a>
  </li>
            
         
              </ul>
               <ul class="nav navbar-nav navbar-right">
                <li><a href="Register.php"><span class="glyphicon glyphicon-user">
                </span> ลงทะเบียน</a>
                </li> <li>
                <a href="who.php">
                <span class="glyphicon glyphicon-log-in">
                </span> เข้าสู่ระบบ
                </a>
              
                <li>
                <form class="navbar-form navbar-right">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search" name="search">
     
        <div class="input-group-btn">
          <button class="btn btn-default" type="default">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>
      </form>
  </li>

  
                <ul>
                  <div>
                    <div>
                  </nav>



        


<!-- <ul>

  <li><a href="#home">Home
  <a href = "template.php">
  </a>
  </a></li>
  <li><a href="#news">Browse Events
  <a href = "browsing.php">
   
   </a>
   </a></li>

  <li><a href="#news">Organize Events
  </a></li>

  <li><a href="#contact">Help</a></li>
  <li><a href="#about">Create Event</a></li>
  <li><a href="signing.php">Sign In
  
   </a>

  </li>

  <li><a href="#about">About</a></li>
</ul> -->
<!-- <div class = "container-fluid">
<div class="row">
   <div class="col-sm-4 bg-primary"><h2>Browse Events </h2></div>
   <div class="col-sm-4 bg-primary"><h2>Organize </h2> </div>
   <div class="col-sm-4 bg-primary"><h2>Help </h2> </div>
   <div class="col-sm-4 bg-primary"><h2>Create Event</h2></div>
   <div class="col-sm-4 bg-primary"><h2>Sign in</h2> </div>
   <div class = "col-sm-4 bg-primary"><h2>About</h2> </div>
   
</div>
</div> -->
<!-- <div class = "container">
  <image src = "2.jpg" class = "img-responsive" alt = "Responsive Image" width = "10000" height = "9000" >
  </div> -->

<!-- <div class = "form-group">
  <label for "comment"><div class = "col-sm-4 bg-"> <h1> Personal Background </h1></label> </div>
  <textarea class="form-control" rows="5" id="comment"></textarea>
  
  
</div> -->

          </div>
          <!-- <div class="input-group">
    <span class="input-group-addon">Text</span>
    <input id="msg" type="text" class="form-control" name="msg" placeholder="Additional Info">
  </div> -->
  

   

      
<!--     
    <div class="row">
      <div class = "column">
      
      <img src="Legend.jpg"  class = "img-responsive "alt="Responsive Image" style="width:100">
     
    </div>
    
    <div class ="column">
    <img src="lol.jpg"  class = "img-responsive "alt="Responsive Image" style="width:500">

  </div>
  <div class ="column">
    <img src="untitled1.png"  class = "img-responsive "alt="Responsive Image" style="width:500">

  </div>
  

  
    </div> -->

    <table  class = "bg-primary"width="100" height="50" border="1" align="center">
  <tr>
  
    <td height="50">
    <b style="font-size:25px;color:#2F4F4F;font-family:Arial"> <p class = "text-danger">Premium </p></h1></b>
		<p>
    <img src="naturee.jpg" width="100" height="50" align="center">
	  	
		<a style="font-size:25px;color:yellow;">zz</a>
		
		</p>
		<p>
		<!-- <a style="font-size:25px;color:black;font-family:verdana"></a> -->
		<a></a>
		</p>
		<button onclick="z1()" class="btn">see more details</button>
        <script>
        function z1(){window.location.href='https://www.eventbrite.com/organizer/pricing/';}
        </script>
		
</td>
</tr>

  
  </table>



<div  class = "container-fluid text-center bg-success" style = "margin-top:800px ; height:40px">
<p class = "b">

<a href = "https://www.google.com" target = "blank">Google </a>
<a href = "https://www.youtube.com" target = "blank"> Youtube </a>
<a href = "https://www.facebook.com" target = "blank">facebook  </a>
<a href = "https://www.instragram.com" target = "blank"> instragram </a>
</p>
</div>

 

 


</body>
</html>