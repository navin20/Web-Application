
class prior:
    def __init__(self,value,priority,check):
        self.value = value
        self.priority = priority
        self.check = check
n = int(input("Enter the number of process:"))
c = []
sortsy = []
e = []
go = []
ki =[]
fcne =[]
fcpo = []
fcne= [0]+fcne
ff =0
fg =0

ui = []
g =[]
v =[]
y =[]
v =[0]+v
y =[0]+y
e = [0]+e
g =[0]+g
c9 = []
def getprior(x):
    return x.priority
for i in range(0,n):
    print("Enter the value of p",i+1)
    d = input()
    c.append(d)
    

for j in range(len(c)):
    c[j] = int(c[j])
print("Process","  ", "Burst Time")

for i in range(n):
    print(i+1,"        " ,c[i])
   

def  robin(wt):
    global c
    
    sum8 =0
    hi = [0]*n
    op = [0]*n
    
    print("Enter Quantum:")
    quantum = int(input())
    rem_bt = [0] * n 
    count =0
    t = 0 
    mk = [0]*n
    u =0
    cui =0
    
    for i in range(n):  
        rem_bt[i] = c[i] 
    t = 0 
  
      
    while(1): 
        done = True
  
       
        for i in range(n): 
              
            
            if (rem_bt[i] > 0) : 
                done = False  
                  
                if (rem_bt[i] > quantum) : 
                  
                   
                    t += quantum  
  
                   
                    rem_bt[i] -= quantum
                    
                  
               
                else: 
                  
                   
                    t = t + rem_bt[i]  
  
                    
                    wt[i] = t - c[i]  
                    rem_bt[i]=0
  
                  
                    
                  
       
        if (done == True): 
            break
        
                
            
                
   
def robs():
    wt = [0]*n
    totalwt = 0
    count =0
    robin(wt)
    
    
    print("Average Waiting time:",sum(wt)/n)
    
    # for k in range(n):
    #     hi[k] = c[k]
    # sum9 =0
     
    # for i in range(n):
    #     if hi[i]>0:
    #         if hi[i]>quantum:
    #             sum9+=quantum
    #             hi[i]-=quantum
    #             op[i]+=(c[i]//quantum)
            
            
            
    #     # print(sum9)

        
    #         else:
    #             sum9  = sum9+hi[i]
    #             op[i] =sum9 -c[i]
    #             hi[i] = 0
    #         print(op[i])
       
                
    #     ki.append(sum9)
    # print(ki)


       




def priority():
    sum6 =0
    sumthing =0
    global m ,c,go
    
    for i in range(n):
        print("enter the priorities",i+1,":")
        u = input()
        go.append(u)
    
    for i in range(n):
        d = prior(i+1,go[i],c[i])
        sortsy.append(d)
    sortsy.sort(key  = getprior,reverse = False)
    print("Process","  ","Burst Time"," ","Priority")
    for i in range(n):

        print(sortsy[i].value,"        " ,sortsy[i].check,"       ",sortsy[i].priority)
        
   
    for i in range(0,len(c)-1):
        sum6+=sortsy[i].check
        v.append(sum6)
    for k in range(len(c)):
        sumthing+=sortsy[k].check
        y.append(sumthing)
    
    for o in range(0,len(y)-1):
        print("p",sortsy[o].value,"=",y[o])  
    print("Average Waiting Time:",(sum(v)/len(c)))

    




    
    
def fcfs():
    global c
    global n
    global ff
    sum1= 0
    sum2 =0
    for i in range(len(c)):
       
        print("Enter the arrival time",i+1,":")
        arrival = input()
        c9.append(arrival)
    for j in range(len(c9)):
        c9[j] = int(c9[j])
        
    
  
   
    for i in range(0,len(c)-1):
        
        sum2+=(c[i])
        
        g.append(sum2)
    for k in range(len(c)):
        
        sum1+=(c[k])
        
        e.append(sum1)
    for i in range(len(c)):
        e[i]-=c9[i]
        ki.append(e[i])
        g[i]-=c9[i]
        fcne.append(g[i])

        
   
        # ff+=e[heyy]-c9[heyy]
        # print(ff)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  

    for o in range(0,len(c)):
        print("p",o,"=",ki[o])  
    print("Average Waiting Time:",(sum(fcne)/len(c)))
def short():
    exit()

print("Choose ur method: 1. fcfs 2. priority 3.round robin")

choose = input()
if choose=="1":
    fcfs()
elif choose=="2":
    priority()
elif choose=="3":
    robs()
else:
    short()

        
        


