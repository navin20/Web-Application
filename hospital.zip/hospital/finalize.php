<!DOCTYPE html>
<!-- saved from url=(0026)http://www.auspark.au.edu/ -->
<html style="" class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface no-generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <title>Login - AU SPARK</title>

    <script type="text/javascript" src="./Login - AU SPARK_files/jquery.min.js.download"></script>
    <script type="text/javascript" src="./Login - AU SPARK_files/jquery.min.js(1).download"></script>

    <link rel="icon" href="http://www.auspark.au.edu/Images/favicon1.ico">
    <link rel="shortcut icon" href="http://www.auspark.au.edu/Images/favicon1.ico">

    <script type="text/javascript" src="./Login - AU SPARK_files/bootstrap.min.js.download"></script>
    <script type="text/javascript" src="./Login - AU SPARK_files/modernizr.js.download"></script>
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" href="./Login - AU SPARK_files/font-awesome.min.css">
    <script>
        ////<!--------------------  Scroll/Follow Sidebar ----------------------------->

        //$(function () {
        //    var offset = $("#sidebarLogin").offset();
        //    var topPadding = 40;
        //    $(window).scroll(function () {
        //        if ($(window).scrollTop() > offset.top) {
        //            $("#sidebarLogin").stop().animate({
        //                marginTop: $(window).scrollTop() - offset.top + topPadding
        //            });
        //        } else {
        //            $("#sidebarLogin").stop().animate({
        //                marginTop: 0
        //            });
        //        };
        //    });
        //});

        ////<!-------------END-------  Scroll/Follow Sidebar ----------------------------->
    </script>
    <script src="./Login - AU SPARK_files/functionDesign.js.download"></script>
    

    <link href="./Login - AU SPARK_files/bootstrap.min.css" rel="stylesheet">
    <link href="./Login - AU SPARK_files/Main.css" rel="stylesheet">


    <script>


        $('#loadingAJAX_TableCourse').fadeOut();
        function loginStudentID(form) {

            document.getElementById("loadingAJAX_TableCourse").setAttribute("style", "z-index:1100; display:block;");
        
            var ID = $("#login_studentID").val()
            var password = $("#login_password").val()

            $.ajax({
                type: "POST",
                url: "/Web/loginStudentID",
                data: { "studentID": ID, "password": password },
                //contentType: "application/json; charset=utf-8",
                dataType: "Json",
                success: successFunc,
                error: errorFunc
            });

            function successFunc(data, status) {
                setTimeout(function () {
                    $('#loadingAJAX_TableCourse').fadeOut();

                }, 10)
               
                if (Boolean(data.isSuccess) != true) {
                    document.getElementById("dvData").innerHTML = "";
                    document.getElementById("dvData").setAttribute("style", "z-index:1100; display:block; ");

                    var elem = document.createElement("img");
                    elem.setAttribute("src", "/images/iconAlert.png");
                    elem.setAttribute("height", "60");
                    elem.setAttribute("width", "60");
                    elem.setAttribute("alt", "Flower");
                    document.getElementById("dvData").appendChild(elem);


                    document.getElementById("dvData").innerHTML += "<p style='margin-top:15px;'>" + data.message + "</p>";
                    document.getElementById("dvData").innerHTML += "<button type='button' class='popupMessageOK' onclick='buttonOK()' style=' float: left; margin-top: -1px; width:100%; margin-top: 10px; border-width:1px; border-style:solid; border-color:#e50000; margin-bottom:0px;'>OK</button>";
                }
                else {
                    document.location.href = "/Web/Schedule";
                    //document.location.href = "/Preview/Reservation";
                }
            }

            function errorFunc() {
                setTimeout(function () {
                    $('#loadingAJAX_TableCourse').fadeOut();

                }, 10)

                messageAlert = "Authentication Failed";
                document.getElementById("dvData").innerHTML = "";
                document.getElementById("dvData").setAttribute("style", "z-index:1100; display:block; ");

                var elem = document.createElement("img");
                elem.setAttribute("src", "/images/iconAlert.png");
                elem.setAttribute("height", "60");
                elem.setAttribute("width", "60");
                elem.setAttribute("alt", "Flower");
                document.getElementById("dvData").appendChild(elem);


                document.getElementById("dvData").innerHTML += "<p style='margin-top:15px;'>" + messageAlert + "</p>";
                document.getElementById("dvData").innerHTML += "<button type='button' class='popupMessageOK' onclick='buttonOK()' style=' float: left; margin-top: -1px; width:100%; margin-top: 10px; border-width:1px; border-style:solid; border-color:#e50000; margin-bottom:0px;'>OK</button>";
            }
        }

        function buttonOK() {
            setTimeout(function () {
                $('#dvData').fadeOut();

            }, 0)
        }
        function popupMessage(message) {

        };

        function ResetPassword() {

            var changePass_studentId = $("#changePass_studentId").val();
            var changePass_currentPassword = $("#changePass_currentPassword").val();
            var changePass_newPassword = $("#changePass_newPassword").val();
            var changePass_confirmNewPassword = $("#changePass_confirmNewPassword").val();

            document.getElementById("loadingAJAX_TableCourse").setAttribute("style", "z-index:1100; display:block;");

            var messageAlert = '';
            $.ajax({
                type: "POST",
                url: "/Web/ResetPassword",
                data: {
                    "studentID": changePass_studentId,
                    "currentPassword": changePass_currentPassword,
                    "newPassword": changePass_newPassword
                },
                //contentType: "application/json; charset=utf-8",
                dataType: "Json",
                success: successFunc,
                error: errorFunc
            });

            function successFunc(data, status) {
                setTimeout(function () {
                    $('#loadingAJAX_TableCourse').fadeOut();

                }, 10)
                console.log(data.result)
                messageAlert = data.message;
                if (data.result != true) {
                    document.getElementById("dvData").innerHTML = "";
                    document.getElementById("dvData").setAttribute("style", "z-index:1100; display:block; ");

                    var elem = document.createElement("img");
                    elem.setAttribute("src", "/images/iconAlert.png");
                    elem.setAttribute("height", "60");
                    elem.setAttribute("width", "60");
                    elem.setAttribute("alt", "Flower");
                    document.getElementById("dvData").appendChild(elem);


                    document.getElementById("dvData").innerHTML += "<p style='margin-top:15px;'>" + messageAlert + "</p>";
                    document.getElementById("dvData").innerHTML += "<button type='button' class='popupMessageOK' onclick='buttonOK()' style=' float: left; margin-top: -1px; width:100%; margin-top: 10px; border-width:1px; border-style:solid; border-color:#e50000; margin-bottom:0px;'>OK</button>";
                }
                else {
                    document.getElementById("dvData").innerHTML = "";
                    document.getElementById("dvData").setAttribute("style", "z-index:1100; display:block; ");

                    var elem = document.createElement("img");
                    elem.setAttribute("src", "/images/iconCorrect.png");
                    elem.setAttribute("height", "60");
                    elem.setAttribute("width", "60");
                    elem.setAttribute("alt", "Flower");
                    document.getElementById("dvData").appendChild(elem);


                    document.getElementById("dvData").innerHTML += "<p style='margin-top:15px;'>" + messageAlert + "</p>";
                    document.getElementById("dvData").innerHTML += "<button type='button' class='popupMessageOK' onclick='buttonOK()' style=' float: left; margin-top: -1px; width:100%; margin-top: 10px; border-width:1px; border-style:solid; border-color:#e50000; margin-bottom:0px;'>OK</button>";
                    //document.location.href = "/Web/Schedule";
                }
            }

            function errorFunc() {

            }
        }

    </script>

    <style>
        /*.modal-header, h4, .close {
            background-color: #5cb85c;
            color: white !important;
            text-align: center;
            font-size: 30px;
        }

        .form-control{
            width: 95%;
        }*/
      
    </style>
</head>
<body class="Body_login" style="background-color:#fff;">

    <div id="dvData" class="popUp_messageStatus"></div>
    <div id="loadingAJAX_TableCourse" class="loading_image_back" style="z-index:0; display:none;"></div>
    <div style="width:100%; float:left; height:94vh; margin:3vh 0px; background-color:#e50000;">
        <div class="box_all_web" style="background-color:transparent; width:955px; margin-top:20px;">
            <div class="box_AU_login">
                <div>
                    <div class="Title_AUspark_login">
                        AU SPARK
                    </div>
                    
                    <div class="text_developedBy_login">
                        OFFICE OF THE UNIVERSITY REGISTRAR
                    </div>
                </div>
                <form id="login_Student" name="form_login" onsubmit="loginStudentID(); return false;">
                    <div class="box_AU_text_login">
                        <div class="box_width_100">
                            <input type="text" id="login_studentID" name="studentID" autofocus="" class="input_username_login" placeholder="Student id">
                        </div>
                        <div class="box_width_100">
                            <input type="password" id="login_password" name="studentPassword" class="input_password_login" placeholder="Password">
                        </div>
                        <div class="box_width_100">
                            <div class="box_button_action_login" style="">
                                <input type="submit" id="buttonLogin" class="button_submit_login" value="Log in">
                            </div>
                        </div>
                        
                    </div>
                </form>

            </div>
            
            
            <div class="login_box_link_url" style="margin-top:50px;">
                <a href="http://www.auspark.au.edu/Web/ClasslookupGlobal" target="_blank">
                    Class Search
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>
                </a>
            </div>
            <div class="login_box_link_url">
                <a href="https://www.facebook.com/AU-Spark-355082151317977/" target="_blank">
                    AU SPARK Facebook Page
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>
                </a>
            </div>
            <div class="login_box_link_url">
                <a href="http://www.registrar.au.edu/" target="_blank">
                    Office of the University Registrar
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>
                </a>
            </div>
            
            <div class="box_bottom_Login">
                <div class="text_developedBy_login">
                    COMPUTER SCIENCE
                </div>
                <div class="text_developedBy_login">
                    ASSUMPTION UNIVERSITY OF THAILAND
                </div>
                
            </div>
        </div>
    </div>
    

    <!-- Modal -->
    <div class="modal fade " id="myModal" role="dialog">
        <div class="modal-dialog" style="width: 30%;">

            <!-- Modal content-->
            <div class="modal_change_password modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">×</button>
                    <h4>Change password</h4>
                </div>
                <div class="modal-body">
                    <div class="row_form">
                        <div class="title_form_1">Student ID <span class="description">(Ex. u5xxxxxx)</span></div>
                        <input type="text" class="input_textfield_form_2" id="changePass_studentId" maxlength="8" placeholder="">
                    </div>
                    <div class="row_form">
                        <div class="title_form_1">Current password</div>
                        <input type="text" class="input_textfield_form_2" id="changePass_currentPassword" placeholder="">
                    </div>
                    <div class="row_form">
                        <div class="title_form_1">New password</div>
                        <input type="text" class="input_textfield_form_2" id="changePass_newPassword" placeholder="">
                    </div>
                    <div class="row_form">
                        <div class="title_form_1">Confirm new password</div>
                        <input type="text" class="input_textfield_form_2" id="changePass_confirmNewPassword" placeholder="">
                    </div>
                    <button type="submit" class="btn_submit_form" onclick="ResetPassword()"><i class="fa fa-paper-plane" aria-hidden="true"></i> Submit</button>
                </div>
               
            </div>

        </div>
    </div>



<script>
    $(document).ready(function () {
        $("#buttonChangePassword").click(function () {
            $("#myModal").modal();
        });
    });
</script></body></html>