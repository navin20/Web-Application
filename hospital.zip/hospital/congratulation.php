<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>My Title</title>

    <!-- Latest compiled and minified CSS --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" integrity="sha384-PmY9l28YgO4JwMKbTvgaS7XNZJ30MK9FAZjjzXtlqyZCqBY6X6bXIkM++IkyinN+" crossorigin="anonymous"> 
    <!-- Optional theme --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap-theme.min.css" integrity="sha384-jzngWsPS6op3fgRCDTESqrEJwRKck+CILhJVO5VvaAZCq8JYf8HsR/HPpBOOPZfR" crossorigin="anonymous"> 
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js" integrity="sha384-vhJnz1OVIdLktyixHY4Uk3OHEwdQqPppqYR8+5mjsauETgLOcEynD9oPHhhz18Nw" crossorigin="anonymous"></script>


    <style>
      body{
        background-color:white;
        background-image: url("2.jpg") 
      }
      * {
  box-sizing: border-box;
}

.column {
  float: left;
  
  
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
  width:30%
}
* {box-sizing: border-box}
.mySlides1, .mySlides2 {display: none}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

div.a{
  text-align:center
}
/* On hover, add a grey background color */
.prev:hover, .next:hover {
  background-color: yellow;
  color: black;
}
ul {

  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: red;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: blue;
}

        </style>
</head>
<body>
<div class="alert alert-success" role="alert"><h1>Congratulation now u can create your event or browse more
     </h1>

</div>

<nav class="navbar navbar-collapse">
 <div class="container-fluid">
  <div class="navbar-header">
   <button type="button" 
   class="navbar-toggle"
    data-toggle="collapse"
     data-target="#myNavbar">
      <span class="icon-bar">
      </span> <span class="icon-bar">
      </span> <span class="icon-bar">
      </span> </button>
       <a class="navbar-brand" 
       href="#">Eventing
       </a>
        </div>
         <div class="collapse navbar-collapse"
          id="myNavbar">
           <ul class="nav navbar-nav">
            <li class="active">
            <a href="template.php">
            Home</a></li>
             <li><a href="pricing.php"
             >Organize Events</a>
             </li>
              <li>
              <a href="CreateEvents.php">
              Create events</a>
              </li> 
              <li>
              <a href="Participants.php">About</a>
              </li>
              <li>
              <a href="ContactLog.php">Contact</a>
              </li>
               </ul>
               <ul class="nav navbar-nav navbar-right">
                <li><a href="template.php"><span class="glyphicon glyphicon-log-out">
                </span> Log Out</a>
                <!-- </li> <li>
                <a href="template.php">
                <span class="glyphicon glyphicon-log-out">
                </span> Log Out
                </a>
                </li>  -->
                </ul> 
                </div>
                 </div>
                  </nav>
<!-- <div class = "container-fluid">
<div class="row">
   <div class="col-sm-4 bg-primary"><h2>Browse Events </h2></div>
   <div class="col-sm-4 bg-primary"><h2>Organize </h2> </div>
   <div class="col-sm-4 bg-primary"><h2>Help </h2> </div>
   <div class="col-sm-4 bg-primary"><h2>Create Event</h2></div>
   <div class="col-sm-4 bg-primary"><h2>Sign in</h2> </div>
   <div class = "col-sm-4 bg-primary"><h2>About</h2> </div>
   
</div>
</div> -->



          <!-- <div class="input-group">
    <span class="input-group-addon">Text</span>
    <input id="msg" type="text" class="form-control" name="msg" placeholder="Additional Info">
  </div> -->

    
        
    
   
  <h1 style="text-align:center"><p class = "text-primary">
    Events </p> </h1>

    <div class="slideshow-container">
  <div class="mySlides1">
  
    <img src="pattaya.jpg" style="width:100%">
  </div>

  <div class="mySlides1">
  <a href = "desi beats.jpg" target = "blank">
    <img src="desi beats.jpg" style="width:100%">
    </a>
  </div>

  <div class="mySlides1">
    <img src="bombay blues.jpg" style="width:100%">
  </div>

  <a class="prev" onclick="plusSlides(-1, 0)">&#10094;</a>
  <a class="next" onclick="plusSlides(1, 0)">&#10095;</a>
</div>


<div class="slideshow-container">
  <div class="mySlides2">
    <img src="fire.jpg" style="width:100%">
  </div>

  <div class="mySlides2">
    <img src="idkk.jpg" style="width:100%">
  </div>

  <div class="mySlides2">
    <img src="nazarlagjayegi.jpg" style="width:100%">
  </div>

  <a class="prev" onclick="plusSlides(-1, 1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1, 1)">&#10095;</a>
</div>

<script>
var slideIndex = [1,1];
var slideId = ["mySlides1", "mySlides2"]
showSlides(1, 0);
showSlides(1, 1);

function plusSlides(n, no) {
  showSlides(slideIndex[no] += n, no);
}

function showSlides(n, no) {
  var i;
  var x = document.getElementsByClassName(slideId[no]);
  if (n > x.length) {slideIndex[no] = 1}    
  if (n < 1) {slideIndex[no] = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";  
  }
  x[slideIndex[no]-1].style.display = "block";  
  setTimeout(showSlides, 2000);
}
</script>
        



</body>
</html>