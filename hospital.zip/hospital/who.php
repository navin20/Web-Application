<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>My Title</title>

    <!-- Latest compiled and minified CSS --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" integrity="sha384-PmY9l28YgO4JwMKbTvgaS7XNZJ30MK9FAZjjzXtlqyZCqBY6X6bXIkM++IkyinN+" crossorigin="anonymous"> 
    <!-- Optional theme --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap-theme.min.css" integrity="sha384-jzngWsPS6op3fgRCDTESqrEJwRKck+CILhJVO5VvaAZCq8JYf8HsR/HPpBOOPZfR" crossorigin="anonymous"> 
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js" integrity="sha384-vhJnz1OVIdLktyixHY4Uk3OHEwdQqPppqYR8+5mjsauETgLOcEynD9oPHhhz18Nw" crossorigin="anonymous"></script>

   
     

    <style>
      body{
        background-image: url("benz.jpg") 
      }

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
  width:30%
}
* {box-sizing: border-box}
.mySlides1, .mySlides2 {display: none}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

div.a{
  text-align:center
}
On hover, add a grey background color */
 .prev:hover, .next:hover {
  background-color: red;
  color: blue;
}
ul {

  /* list-style-type: none; */
  margin: 0;
  padding: 0;
  /* overflow: hidden; */
  background-color: yellow;
}

li {
  float: right;
}

li a {
  display: block;
  color: white;
  text-align: center; */
   padding: 14px 16px;
  text-decoration: none;
}
#links { 
    margin: 0 auto; 
    width: 3000px; 
    font-size:70px;
    clear: both; 
    display: block;
}
#test a {
    float: right;
}
p.b { 
  word-spacing: 30px;
}
}

</style>
</head>
<body>
<div class = "container-fluid text-center"> <h1> WHO </h1> </div>
<div class = "container-fluid text-center" style = "margin-top:100px">
<a href = "signing.php"><h1><font size ="100"  >Nurse</font></h1> </a></div>
<div class = "container-fluid text-center" style = "margin-top:80px"><a href="AdminConfirmation.php">
     <img src = "privateigno.png" style = "width:200px"> </a>
      </div>
<div class = "container-fluid text-center" style = "margin-top:100px">
<a href = "participantlog.php"> <h1><font size ="300"> Doctor</font></h1> </a> </div>



</body>
</html>