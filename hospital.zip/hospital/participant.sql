using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Event_registration
{
    #region Participant
    public class Participant
    {
        #region Member Variables
        protected int _id;
        protected string _first_name;
        protected string _last_name;
        protected string _email;
        protected int _phone;
        protected string _my_event_id;
        protected unknown _register_date;
        protected int _reference_code;
        #endregion
        #region Constructors
        public Participant() { }
        public Participant(string first_name, string last_name, string email, int phone, string my_event_id, unknown register_date, int reference_code)
        {
            this._first_name=first_name;
            this._last_name=last_name;
            this._email=email;
            this._phone=phone;
            this._my_event_id=my_event_id;
            this._register_date=register_date;
            this._reference_code=reference_code;
        }
        #endregion
        #region Public Properties
        public virtual int Id
        {
            get {return _id;}
            set {_id=value;}
        }
        public virtual string First_name
        {
            get {return _first_name;}
            set {_first_name=value;}
        }
        public virtual string Last_name
        {
            get {return _last_name;}
            set {_last_name=value;}
        }
        public virtual string Email
        {
            get {return _email;}
            set {_email=value;}
        }
        public virtual int Phone
        {
            get {return _phone;}
            set {_phone=value;}
        }
        public virtual string My_event_id
        {
            get {return _my_event_id;}
            set {_my_event_id=value;}
        }
        public virtual unknown Register_date
        {
            get {return _register_date;}
            set {_register_date=value;}
        }
        public virtual int Reference_code
        {
            get {return _reference_code;}
            set {_reference_code=value;}
        }
        #endregion
    }
    #endregion
}