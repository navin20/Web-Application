<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>My Title</title>

    <!-- Latest compiled and minified CSS --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" integrity="sha384-PmY9l28YgO4JwMKbTvgaS7XNZJ30MK9FAZjjzXtlqyZCqBY6X6bXIkM++IkyinN+" crossorigin="anonymous"> 
    <!-- Optional theme --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap-theme.min.css" integrity="sha384-jzngWsPS6op3fgRCDTESqrEJwRKck+CILhJVO5VvaAZCq8JYf8HsR/HPpBOOPZfR" crossorigin="anonymous"> 
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js" integrity="sha384-vhJnz1OVIdLktyixHY4Uk3OHEwdQqPppqYR8+5mjsauETgLOcEynD9oPHhhz18Nw" crossorigin="anonymous"></script>

   <style>
   body{
    background-image:url("benz.jpg")
   }

   </style>
   </head>
   <body>
   <div class ="container-fluid text-center" style ="width:200px" >
   <p class = "text-danger">
   <font size = "100">
   Participant Page
   </font>
   </p>
   </div>
 
   

<div class = "container">
   <div class = "table-responsive" style = "margin-top:10px">
    <table class = "table table-bordered" >
  
    
    
      <tr>
        <td>  <p style = "color:green">    VMS 2019  </font> </p </td>
        </tr>
        <tr>
        
        <td> <p style = "color:red">   vms 2019 day celebration of science and technology faculty in which they will be booths of game and un activities location:vms abac
          </font> </p></td>
        </tr>
        <tr>
        <td> <p style = "color:blue">
        event date:21/01/2019   </p></td>
        </tr>
        
        <td><p style = "color:blue"> event time:12:40:35pm  </font> </p></td>
        </tr>
        <tr>

        <td>  <p style = "color:yellow">Location:vms/abac/samutprakarn  </font></p></td>
        </tr>

        <tr>

<td>  <p style = "color:yellow">deadline:21/09/2019  </font></p></td>

</tr>
<tr>
<td>  <p style = "color:blue">more details contact:</p>
<a href = "http://www.scitech.au.edu/Contact" target = "blank"> abac vms </a> </td>
  </tr>


   

  <div class = "container">
   <div class = "table-responsive" style = "margin-top:10px">
    <table class = "table table-bordered" >
  
    
    
      <tr>
        <td>  <p style = "color:green">    Thai Indian Fun Fair  </font> </p </td>
        </tr>
        <tr>
        
        <td> <p style = "color:red">  India Thailand Quiz Contest team of Thai-Indian Fun Fair 2019 conducts weekly meeting to review progress. More than 20 teams already registered from leading schools and universities in Bangkok.
          </font> </p></td>
        </tr>
        <tr>
        <td> <p style = "color:blue">
        event date:16 Jan 2019   </p></td>
        </tr>
        
        <td><p style = "color:blue"> event time:12:40:35pm  </font> </p></td>
        </tr>
        <tr>

        <td>  <p style = "color:yellow">Location:Sri nakhrarin University  </font></p></td>
        </tr>

        <tr>

<td>  <p style = "color:yellow">deadline:21/01/2019  </font></p></td>

</tr>
<tr>
<td>  <p style = "color:blue">more details contact:</p>
<a href = "https://www.facebook.com/IndianSocialClubThailand/photos/gm.277594839616550/2089559774444231/?type=3" target = "blank"> fun fair </a> </td>
  </tr>

    
        
      
        

    </table>
</div>
   </body>
   </html>