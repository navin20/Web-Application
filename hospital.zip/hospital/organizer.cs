using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Event_registration
{
    #region Organizer
    public class Organizer
    {
        #region Member Variables
        protected int _id;
        protected string _first_name;
        protected string _last_name;
        protected string _organization;
        protected string _address;
        protected int _phone;
        protected string _email;
        protected string _password;
        protected unknown _register_date;
        protected bool _activated;
        #endregion
        #region Constructors
        public Organizer() { }
        public Organizer(string first_name, string last_name, string organization, string address, int phone, string email, string password, unknown register_date, bool activated)
        {
            this._first_name=first_name;
            this._last_name=last_name;
            this._organization=organization;
            this._address=address;
            this._phone=phone;
            this._email=email;
            this._password=password;
            this._register_date=register_date;
            this._activated=activated;
        }
        #endregion
        #region Public Properties
        public virtual int Id
        {
            get {return _id;}
            set {_id=value;}
        }
        public virtual string First_name
        {
            get {return _first_name;}
            set {_first_name=value;}
        }
        public virtual string Last_name
        {
            get {return _last_name;}
            set {_last_name=value;}
        }
        public virtual string Organization
        {
            get {return _organization;}
            set {_organization=value;}
        }
        public virtual string Address
        {
            get {return _address;}
            set {_address=value;}
        }
        public virtual int Phone
        {
            get {return _phone;}
            set {_phone=value;}
        }
        public virtual string Email
        {
            get {return _email;}
            set {_email=value;}
        }
        public virtual string Password
        {
            get {return _password;}
            set {_password=value;}
        }
        public virtual unknown Register_date
        {
            get {return _register_date;}
            set {_register_date=value;}
        }
        public virtual bool Activated
        {
            get {return _activated;}
            set {_activated=value;}
        }
        #endregion
    }
    #endregion
}