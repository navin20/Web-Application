<!doctype html>

<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>My Title</title>

    <!-- Latest compiled and minified CSS --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" integrity="sha384-PmY9l28YgO4JwMKbTvgaS7XNZJ30MK9FAZjjzXtlqyZCqBY6X6bXIkM++IkyinN+" crossorigin="anonymous"> 
    <!-- Optional theme --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap-theme.min.css" integrity="sha384-jzngWsPS6op3fgRCDTESqrEJwRKck+CILhJVO5VvaAZCq8JYf8HsR/HPpBOOPZfR" crossorigin="anonymous"> 
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js" integrity="sha384-vhJnz1OVIdLktyixHY4Uk3OHEwdQqPppqYR8+5mjsauETgLOcEynD9oPHhhz18Nw" crossorigin="anonymous"></script>
<style>

.error {
           color: #FF0000;
    }
    body{
       background-image : url("ironman.jpg");
    }
      
    </style>

</head>

<body>
<?php
// define variables and set to empty values
$nameErr = $emailErr = $genderErr = $websiteErr = "";
$name = $email = $gender = $comment = $website = "";
$commenting = "";
$i = strlen($comment);


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["first name"])) {
    $nameErr = "firstname is required";
  } else {
    $name = test_input($_POST["first name"]);
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Accident time is required";
  } else {
    $email = test_input($_POST["email"]);
  }
    
  if (empty($_POST["last name"])) {
    $website = "last name is required";
  } else {
    $website = test_input($_POST["last name"]);
  }

  if (empty($_POST["pwd"])) {
    $commenting = "causes of accident is very importanttt";
  } else {
    $comment = test_input($_POST["pwd"]);
    

  
}

  if (empty($_POST["phonenumber"])) {
    $genderErr = "we need ur phone number asap";
  } else {
    $gender = test_input($_POST["phonenumber"]);
  }
}

function test_input($data) {

    return $data;
}
?>

<div class="container text-center"  style = "margin-bottom:10px">
  <h1>
  <p class  = "text-danger">
  Emergency Form
  </p></h1>
  </div>

  <div class = "container text-center" style = "width:100%">

  <form class = form-horizontal  action="related.php" method ="post">
 
    <div class="form-group">
      <label class="control-label col-sm-2" for="time">
      <p class  = "text-warning"> Accident Time:</p> </label>
      <div class="col-sm-8">
        <input type="time" class="form-control" id="time" placeholder="Enter time of accident" name="email" value  = "<?php echo $email;?>">
        <span class = "error">|| <?php echo $emailErr; ?> </span>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2">
      <p class  = "text-warning"> First Name</p> </label>
      <div class="col-sm-8">
        <input type="text" class="form-control" id="first name" placeholder="Enter Patient First Name" name="first name">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" >
      <p class  = "text-warning"> Last Name</p> </label>
      <div class="col-sm-8">
        <input type="text" class="form-control" id="last name" placeholder="Enter Patient Last Name" name="last name">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd"> <p class  = "text-warning">cause: </p></label>
      <div class="col-sm-8">          
        <input type="text" class="form-control" id="pwd" placeholder="Enter the causes of the accident" name="pwd" value = "<?php echo $comment;?>">
        <span class = "error">* <?php echo $commenting; ?> </span>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">
      <p class  = "text-warning"> Phone Number</p> </label>
      <div class="col-sm-8">
        <input type="text" class="form-control" id="phonenumber" placeholder="Enter Phone Number" name="phonenumber" value = "<?php echo $gender;?>">
        <span class = "error"> * <?php echo $genderErr; ?> </span>
</div>
</div>
        <div class = "container-fluid">
      <button type = "submit" class = "btn btn-danger btn-lg"> 
        submit
    
     
    
      


</button>
</div>

</form>


</p>
</button>
</div>
</div>



    


</body>
</html>