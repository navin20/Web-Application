<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>My Title</title>

    <!-- Latest compiled and minified CSS --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" integrity="sha384-PmY9l28YgO4JwMKbTvgaS7XNZJ30MK9FAZjjzXtlqyZCqBY6X6bXIkM++IkyinN+" crossorigin="anonymous"> 
    <!-- Optional theme --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap-theme.min.css" integrity="sha384-jzngWsPS6op3fgRCDTESqrEJwRKck+CILhJVO5VvaAZCq8JYf8HsR/HPpBOOPZfR" crossorigin="anonymous"> 
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js" integrity="sha384-vhJnz1OVIdLktyixHY4Uk3OHEwdQqPppqYR8+5mjsauETgLOcEynD9oPHhhz18Nw" crossorigin="anonymous"></script>

   
     

    <style>
      body{
        background-color:white;
        background-image: url("2.jpg")
       
      }
      * {
  box-sizing: border-box;
}

.column {
  float: left;
  
  
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
  width:30%
}
* {box-sizing: border-box}
.mySlides1, .mySlides2 {display: none}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

div.a{
  text-align:center
}
/* On hover, add a grey background color */
.prev:hover, .next:hover {
  background-color: yellow;
  color: black;
}
ul {

  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: red;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: blue;
}

        </style>
        

  </head>
  <body>

<!-- insert your codes here -->

<nav class="navbar navbar-inverse">
 <div class="container-fluid">
  <div class="navbar-header">
   <button type="button" 
   class="navbar-toggle"
    data-toggle="collapse"
     data-target="#myNavbar">
      <span class="icon-bar">
      </span> <span class="icon-bar">
      </span> <span class="icon-bar">
      </span> </button>
       <a class="navbar-brand" 
       href="#">Eventing
       </a>
        </div>
         <div class="collapse navbar-collapse"
          id="myNavbar">
           <ul class="nav navbar-nav">
            <li class="active">
            <a href="template.php">
            Home</a></li>
             <li><a href="#"
             >Organize Events</a>
             </li>
              <li>
              <a href="#">
              Create events</a>
              </li> 
              <li>
              <a href="#">About</a>
              </li> 
              
              </ul>
               <ul class="nav navbar-nav navbar-right">
                <li><a href="template.php"><span class="glyphicon glyphicon-log-out">
                </span> Log Out </a>
                 </li>
                 <!-- <li>
                <a href="signing.php">
                <span class="glyphicon glyphicon-log-in">
                </span> Log in
                </a>
                </li>  --> -->
                </ul> 
                </div>
                 </div>
                  </nav>

                  <div class = "Container">
  <div class = "text-danger">
  <h1>
    Our Contact Info
    </h1>
</div>
    <div>


<!-- <div class="column">
    <img src="lol.jpg"  class = "img-responsive "alt="Responsive Image" style="width:300px">
  </div> -->
  <div class = "container-fluid">
  <div class = "table-responsive bg-light" style = "margin-top:80px">
    <table class = "table table-responsive ">
   
      
      <tr>
        <td>
          <p class = text-danger> 
            Name   </p></td>
        <td> <p class = text-danger>  Email </p></td>
        <td> <p class = text-danger> Phone Number</p></td>
        
        <td> <p class =text-danger>Line id </p></td>
        <td> <p class = text-danger>Facebook</p> </td>
    </tr>
    
    <tr>
        <td> <p class = text-danger>Navin Singh </p> </td>
        <td> <p class = text-danger> navinrow@gmail.com </p></td>
        <td><p class  = text-danger> 0909875223</p></td>
        
        <td> <p class  = text-danger> navinrow </p></td>
        <td> <p class = text-danger> Navin Singh </p></td>
    </tr>


    <tr>
        <td><p class = text-danger>UnKnown</p></td>
        <td> <p class = text-danger>unknown@gmail.com</p></td>
        <td><p class = text-danger> 0909872111</p></td>
        
        <td><p class = text-danger> idk</p> </td>
        <td><p class = text-danger> dk</p></td>
    </tr>

        

    </table>
    </div>
    

<div class = "container-fluid">
    <div class="row">
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="Legend.jpg" target="_blank">
          <img src="Legend.jpg" alt="Navin" style="width:450%">
          <div class="caption">
           
          </div>
        </a>
      </div>
    </div>
    
    <!-- <iframe width="500" height="600" src="Ethics.mp4">
</iframe> -->
    
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="na.jpg" target="_blank">
          <img src="na.jpg" alt="IDK" style="width:500%">
          <div class="caption">
           
          </div>
        </a>
      </div>
    </div>
    
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="wd,l.jpg" target="_blank">
          <img src="wd,l.jpg" alt="IDK" style="width:500%">
          <div class="caption">
           
          </div>
        </a>
      </div>
    </div>
    
  </div>
</div>    



</body>
</html>