<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>My Title</title>

    <!-- Latest compiled and minified CSS --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" integrity="sha384-PmY9l28YgO4JwMKbTvgaS7XNZJ30MK9FAZjjzXtlqyZCqBY6X6bXIkM++IkyinN+" crossorigin="anonymous"> 
    <!-- Optional theme --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap-theme.min.css" integrity="sha384-jzngWsPS6op3fgRCDTESqrEJwRKck+CILhJVO5VvaAZCq8JYf8HsR/HPpBOOPZfR" crossorigin="anonymous"> 
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js" integrity="sha384-vhJnz1OVIdLktyixHY4Uk3OHEwdQqPppqYR8+5mjsauETgLOcEynD9oPHhhz18Nw" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css?family=Amaranth|Parisienne|Titan+One" rel="stylesheet">
    <!-- <link href="mystyle.css" rel="stylesheet"> -->
   
     
        
<style>
body{
  background-image:url(ironman.jpg);
  font-family: 'Titan One', cursive;
}
p.b { 
word-spacing: 30px;
margin-bottom:0px

}
</style>
  </head>
  <body>
  <nav class="navbar navbar-inverse bg-primary" style = "margin-bottom:0px"> <div class="container-fluid">
 <div class="navbar-header"> 
 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
  <span class="icon-bar">
  </span>
 <span class="icon-bar">
</span> <span class="icon-bar"></span>
 </button> 
 <a class="navbar-brand" href="www.youtube.com">
 Eventing</a>
  </div> 
  <div class="collapse navbar-collapse" id="myNavbar">
   <ul class="nav navbar-nav"> 
   <li class="active">
   <a href="#">
   Home
   </a>
   </li>
   <li>
   <a href="CreateEvents.php">
   create Events
   </a>
   </li>
    <li>
    <a href="about.php">
    Events</a>
    </li> 
    <li>
    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
    Organize
     <span class="caret">
     </span>
     </a> 
     <ul class="dropdown-menu">
      <li><a href="#">
      overview
      </a>
      </li>
        <li>
       <a href="pricing.php">
       pricing
       </a>
       </li>
       
      
        </ul> 
        <li>
       <a href = "Contact.php">
       Contact Info
       </a>
       </li>
        </li>
    
    </a>
    </li>
     </ul>
      <ul class="nav navbar-nav navbar-right">
       <li>
       <a href="register.php">
       <span class="glyphicon glyphicon-user">
       </span>
        Sign Up
        </a>
        </li>
         <li>
         <a href="who.php">
         <span class="glyphicon glyphicon-log-in">
         </span>
          Login
          </a>


</li> 
<form class="navbar-form navbar-right" action="https://www.google.com/">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search" name="search">
     
        <div class="input-group-btn">
          <button class="btn btn-default" type="submit">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>

  
        

</ul> </div> </div> </nav>
  <!-- <nav class="navbar navbar-inverse bg-primary" style = "margin-bottom:0px"> 
  <div class="container-fluid bg-primary"> 
  <div class="navbar-header col-xs-2"> 
  <a class="navbar-brand" href="https://www.youtube.com/watch?v=kckDWrICC4s">
  Eventing
  </a> 
  </div> 
  <ul class="nav navbar-nav bg-primary">
   <li class="active  bg-primary">
   <a href="#">
   Home
   </a>
   </li>
    <li>
    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
    Organize
     <span class="caret">
     </span>
     </a> 
     <ul class="dropdown-menu">
      <!-- <li><a href="#">
      overview
      </a>
      </li> -->
       <!-- <li>
       <a href="pricing.php">
       pricing
       </a>
       </li>
      
        </ul> 
        </li>
         <li>
         <a href="CreateEvents.php">
        create Events
         </a>
         </li> 
         <li>
         <a href="Contact.php">
         Contact
         </a>
         </li> 
         <li>
         <a href="about.php">
        Events
         </a>
         </li> 
         </ul> 
 
   <ul class="nav navbar-nav navbar-right bg-primary">
                <li><a href="Register.php"><span class="glyphicon glyphicon-user">
                </span> Register</a>
                </li> <li>
                <a href="who.php" target = "blank">
                <span class="glyphicon glyphicon-log-in">
                </span> Login
                </a>
                </li>
               
                <form class="navbar-form navbar-right" action="https://www.google.com/">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search" name="search">
     
        <div class="input-group-btn">
          <button class="btn btn-default" type="submit">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>
      
      
               
               
                 </a>
                
  
  
</div>

    </form>
    </ul>
                </div>
                 </div>
                </nav> --> 
                
                 

</div>
<div class="slideshow-container-fluid" style ="margin:0px">
  

  <div class="mySlides1" style>
  <a href = "Participants.php" target = "blank">
    <img src="18.jpg" style="width:100%">
    </a>
  </div>

  <div class="mySlides1">
  <a href = "Participants.php" target = "blank">
    <img src="bombay blues.jpg" style="width:100%">
    </a>
  </div>

  <!-- <a class="prev" onclick="plusSlides(-1, 0)">&#10094;</a>
  <a class="next" onclick="plusSlides(1, 0)">&#10095;</a> -->
</div>


<div class="slideshow-container-fluid" style = "margin:0px">
  <div class="mySlides2">
  <a href = "Participants.php" target = "blank">
    <img src="novotel.jpg" style="width:100%">
    </a>
  </div>

  <div class="mySlides2">
  <a href= "Participants.php" target  ="blank">
    <img src="place.jpg" style="width:100%">
    </a>
  </div>

  <div class="mySlides2">
  <a href = "Participants.php" target = "blank">
    <img src="pattaya.jpg" style="width:100%">
    </a>
  </div>

  <!-- <a class="prev" onclick="plusSlides(-1, 1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1, 1)">&#10095;</a> -->
</div>
                


<script>
var slideIndex = [1,1];
var slideId = ["mySlides1", "mySlides2"]
showSlides(1, 0);
showSlides(1, 1);

function plusSlides(n, no) {
  showSlides(slideIndex[no] += n, no);
}

function showSlides(n, no) {
  var i;
  var x = document.getElementsByClassName(slideId[no]);
  if (n > x.length) {slideIndex[no] = 1}    
  if (n < 1) {slideIndex[no] = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";  
  }
  x[slideIndex[no]-1].style.display = "block";  
  setTimeout(showSlides, 2000);
}


</script>
                

<!-- insert your codes here -->
<!-- 
<nav class="navbar navbar-inverse">
 <div class="container-fluid">
  <div class="navbar-header">
   <button type="button" 
   class="navbar-toggle"
    data-toggle="collapse"
     data-target="#myNavbar">
      <span class="icon-bar">
      </span> <span class="icon-bar">
      </span> <span class="icon-bar">
      </span> </button>
       <a class="navbar-brand" 
       href="template.php">Eventing
       </a>
        </div>
         <div class="collapse navbar-collapse"
          id="myNavbar">
           <ul class="nav navbar-nav">
            <li class="active">
            <a href="template.php">
            Home</a></li>
             <li><a href="Log In Organize.php"
             >Organize Events</a>
             </li>
              <li>
              <a href="#">
              Create events</a>
              </li> 
              <li class="dropdown">
    <button class="dropbtn">About
      <i class="fa fa-caret-down"></i>
    </button>
    <li class="dropdown-content">
      <a href="#">Link 1</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </li>
  
        
              </li> 
              <li>
              <a href="Contact.php">Contact</a>
              </li> 
              </ul>
              
<!-- <ul>

  <li><a href="#home">Home
  <a href = "template.php">
  </a>
  </a></li>
  <li><a href="#news">Browse Events
  <a href = "browsing.php">
   
   </a>
   </a></li>

  <li><a href="#news">Organize Events
  </a></li>

  <li><a href="#contact">Help</a></li>
  <li><a href="#about">Create Event</a></li>
  <li><a href="signing.php">Sign In
  
   </a>

  </li>

  <li><a href="#about">About</a></li>
</ul> -->
<!-- <div class = "container-fluid">
<div class="row">
   <div class="col-sm-4 bg-primary"><h2>Browse Events </h2></div>
   <div class="col-sm-4 bg-primary"><h2>Organize </h2> </div>
   <div class="col-sm-4 bg-primary"><h2>Help </h2> </div>
   <div class="col-sm-4 bg-primary"><h2>Create Event</h2></div>
   <div class="col-sm-4 bg-primary"><h2>Sign in</h2> </div>
   <div class = "col-sm-4 bg-primary"><h2>About</h2> </div>
   
</div>
</div> -->
<!-- <div class = "container">
  <image src = "imaging.jpg" class = "img-responsive" alt = "Responsive Image" width = "10000" height = "9000" >
  </div> -->

<!-- <div class = "form-group">
  <label for "comment"><div class = "col-sm-4 bg-"> <h1> Personal Background </h1></label> </div>
  <textarea class="form-control" rows="5" id="comment"></textarea>
  
  
</div> -->

          </div>
          <!-- <div class="input-group">
    <span class="input-group-addon">Text</span>
    <input id="msg" type="text" class="form-control" name="msg" placeholder="Additional Info">
  </div> -->
  <!-- <h1 style="text-align:center"><p class = "text-primary">
    Events </p> </h1> -->

    <!-- <div class="container">
  <a href = "Participants.php" target = "blank">
    <img src="online-business-meeting.jpg" style="width:25%" alt = "Paris" class = "center">
    </a>
  </div> -->

        <!-- <div class = "container-fluid">
        <div class="card" style="width:300px">
    <img class="card-img-top" src="images23.jpg" alt="Card image" style="width:100%">
    <div class="card-body">
      
     
      <a href="#" class="btn btn-primary">more</a>
    </div>
  </div>

  </div> -->

      
<!--     
    <div class="row">
      <div class = "column">
      
      <img src="Legend.jpg"  class = "img-responsive "alt="Responsive Image" style="width:100">
     
    </div>
    
    <div class ="column">
    <img src="lol.jpg"  class = "img-responsive "alt="Responsive Image" style="width:500">

  </div>
  <div class ="column">
    <img src="untitled1.png"  class = "img-responsive "alt="Responsive Image" style="width:500">

  </div>
   

  
    </div> -->
    


    <div class="container-fluid  text-center bg-danger" style = "margin-top:600px ; height:100px">
<p class = "b">


<a href = "template.php" target = "blank">Use Eventing</a> 
        
       
  <a href = "https://www.tinder.com">FAQs </a>
  <a href = "Contact.php">More details contact 0909875223</a>
  <a href = "CreateEvents.php" >Plan Events</a>
  
  <a href = "https://www.twitter.com/">Twitter</a>
  <a href = "https://www.facebook.com/">Facebook</a>
  
  <a href = "https://www.instagram.com/">Instagram</a>
  <a href = "https://www.snapchat.com/"> snapchat</a>
 <a href = "https://www.googleplus.com/"> Google+</a>

</p>
</div> 


</body>
</html>

   

 

