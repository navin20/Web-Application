<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>My Title</title>

    <!-- Latest compiled and minified CSS --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" integrity="sha384-PmY9l28YgO4JwMKbTvgaS7XNZJ30MK9FAZjjzXtlqyZCqBY6X6bXIkM++IkyinN+" crossorigin="anonymous"> 
    <!-- Optional theme --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap-theme.min.css" integrity="sha384-jzngWsPS6op3fgRCDTESqrEJwRKck+CILhJVO5VvaAZCq8JYf8HsR/HPpBOOPZfR" crossorigin="anonymous"> 
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js" integrity="sha384-vhJnz1OVIdLktyixHY4Uk3OHEwdQqPppqYR8+5mjsauETgLOcEynD9oPHhhz18Nw" crossorigin="anonymous"></script>

   <style>
   body{
    background-image:url("benz.jpg")
   }

	 </style>
	 </head>
	<body>
  

    <div class = "container-fluid text-center bg-primary" style = "margin-top:0px" >
      <h1>
        Events
  </h1>
  </div>

<table width="900" height="215" border = "5" align="center" class="bg-info">

  <tr>
    <td height="34"><img src="indian.jpg" width="380" height="215" align="left">
	  	<p class = "text-info">Thai indian fun fair</p>
		<p class = "text bg-info">
		Date:16 Jan 2019
    </p>
		<a>
		</p>
		<p>
		Location:
		Sri nakhrarin University
    </p>
    <!-- Java Script Part   xoxox -->
		<button onclick="z1()" class="btn">see more details</button>
        <script>
        function z1(){window.location.href='https://www.evensi.com/thai-indian-fun-fair-2019-srinakharinwirot-university/284128814';}
        </script>
		
</td>
</tr>


  
  </table>

  
<table width="900" height="215" border = "5" align="center" class = "bg-info">
  <tr>
    <td height="34"><img src="342.jpg" width="380" height="215" align="left">
	  Workshop: Software Architectures
		<p class = "text-primary">
		Date:
		<a>Feb 23 2019
		</p>
		<p>
		Location:
		248 Krungthonburi Road, Bangkok, Thailand 10600
    </p>
    <!-- Java Script Part   xoxox -->
		<button onclick="z2()" class="btn">see more details</button>
        <script>
        function z2(){window.location.href='https://web.facebook.com/3DigitsAcademy/photos/gm.401340653768249/541353093029272/?type=3';}
        </script>
		
</td>
</tr>

  
  </table>


  <div class = "container text-center">
  <form class="form-horizontal">
 
    
    
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-1" style:"margin-top:200px">
        <button type="submit" class="btn btn-default">
        <a href = "template.php" target = "blank">
        back to homepage 
        </a>
        </button>
      </div>
    </div>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-1">
        <button type="submit" class="btn btn-default">
        <a href = "signing.php">
        go to congratulation page
        </a>
        </button>
      </div>
    </div>
</div>
  </form>
</div>


		
</body>
</html>