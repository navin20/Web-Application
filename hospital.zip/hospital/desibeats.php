<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>My Title</title>

    <!-- Latest compiled and minified CSS --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" integrity="sha384-PmY9l28YgO4JwMKbTvgaS7XNZJ30MK9FAZjjzXtlqyZCqBY6X6bXIkM++IkyinN+" crossorigin="anonymous"> 
    <!-- Optional theme --> 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap-theme.min.css" integrity="sha384-jzngWsPS6op3fgRCDTESqrEJwRKck+CILhJVO5VvaAZCq8JYf8HsR/HPpBOOPZfR" crossorigin="anonymous"> 
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js" integrity="sha384-vhJnz1OVIdLktyixHY4Uk3OHEwdQqPppqYR8+5mjsauETgLOcEynD9oPHhhz18Nw" crossorigin="anonymous"></script>

   
     

    <style>
      body{
     
       background-image:url("2.jpg")
       
        /* background-repeat: no-repeat, repeat; */
      
      }
      
}

        </style>
        

  </head>
  <body>
  <nav class="navbar navbar-inverse">
 <div class="container-fluid">
  <div class="navbar-header">
   <button type="button" 
   class="navbar-toggle"
    data-toggle="collapse"
     data-target="#myNavbar">
      <span class="icon-bar">
      </span> <span class="icon-bar">
      </span> <span class="icon-bar">
      </span> </button>
       <a class="navbar-brand" 
       href="#">Eventing
       </a>
        </div>
         <div class="collapse navbar-collapse"
          id="myNavbar">
           <ul class="nav navbar-nav">
            <li class="active">
            <a href="#">
            Home</a></li>
             <li><a href="Log In Organize.php"
             >Organize Events</a>
             </li>
              <li>
              <a href="#">
              Create events</a>
              </li> 
              <li>
              <a href="#">About</a>
              </li> 
              <li>
              <a href="Contact.php">Contact</a>
              </li> 
              </ul>
               <ul class="nav navbar-nav navbar-right">
                <li><a href="Register.php"><span class="glyphicon glyphicon-user">
                </span> Register</a>
                </li> <li>
                <div class = "container-fluid">
<img src ="evebt.jpg" alt = "Responsive-Image" class = "img-responsive" style = "width:8000px" style = " height:9000px">
</div> 
</nav>


 
<div class="container-fluid  text-center bg-danger" style = "margin-top:0px">
<p class = "text-primary">


  

  



  139 Soi Thonglor 10 | Opus Bldg , Khlong Tan Nuea , Watthana, Bangkok 10110, Thailand
+66 81 683 8889
</p>
</div> 

</body>
</html>
<!-- 
<div class = "container-fluid"> 



